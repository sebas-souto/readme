//PROGRAMA BIBLIOTECA
#include "biblioteca.h"
#include "base_datos.h"
#include "pantalla.h"

int main(){
	if (comprobacion()==0) return 1;	//COMPRUEBA LOS TXT Y SI ESTAN MAL FORMADOS SE DETIENE EL PROGRAMA
	caratula('#',80,"BIBLIOTECA"); //IMPRIMIMOS LA CARTULA CON LOS PARAMETROS QUE LLEGAN DESDE BIBLIOTECA
	menu();
	return 0;}

void caratula(char simbolo, int ancho, char *texto){
	base(simbolo,ancho);
	lados(simbolo,ancho,2);
	titulo(simbolo,ancho,texto);
	lados(simbolo,ancho,2);
	base(simbolo,ancho);
	return;}
		
void menu(){
	char cadena[256];
	int tam_lec, tam_ref;	
	do{
		tam_lec=leer_lector();
		tam_ref=leer_referencia();
		printf("\n1) Incorporar lector\n2) Agregar referencia\n3) Expresar opinion\n4) Obtener informe\n5) Emitir voto\n6) Calcular nota\n7) Listar referencias\n8) Buscar referencia\n9) Cambiar lector\n0) Salir\n\nSiguiente comando? ");
		fgets(cadena,sizeof(cadena),stdin);
		if (cadena[1]!='\n') cadena[0]='X';	//SI NO SE INTRODUCE UN SOLO CARACTER INVALIDA EL 1o
		switch (cadena[0]){
			case '1':
				lector(&tam_lec);
				actualizar_lector(tam_lec);
				break;
			case '2':
				referencia(&tam_ref);
				actualizar_refe(tam_ref);
				break;
			case '3':
				opinion(tam_ref,tam_lec);
				actualizar_refe(tam_ref);
				break;
			case '4':
				informa(tam_ref);
				break;
			case '5':
				voto(tam_ref);
				actualizar_refe(tam_ref);
				break;
			case '6':
				nota(tam_ref);
				break;
			case '7':
				listar(tam_ref);
				break;
			case '8':
				buscar(tam_ref);
				break;
			case '9':
				cambiar(tam_lec);
				actualizar_lector(tam_lec);
				break;
			case '0':
				cadena[0]=confirmar();
				break; //SI SE SELECCIONA SI IGUALA cadena[0] A 0 SALIENDO DEL WHILE
			default:
				printf("\nHas realizado una seleccion no valida\n");
				break;}//switch
	}while (cadena[0]!=0);
	return;}
