#define ANCHO_MAXIMO 90
#include <stdio.h>
#include <string.h>
#include <ctype.h>
void lados(char simbolo, int ancho, int lineas);
void base(char simbolo, int ancho);
int titulo(char simbolo, int ancho, char *texto);
int confirmar();
