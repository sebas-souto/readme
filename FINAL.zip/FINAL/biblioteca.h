#include <stdio.h>
void caratula(char simbolo, int ancho, char *texto);
void menu();
