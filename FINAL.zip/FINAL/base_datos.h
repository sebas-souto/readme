#define MAX_LONG_CODIGO 32767
#define MAX_LONG_NOMBRE 50
#define MAX_LONG_SINGNATURA 2147483647
#define MAX_LONG_AUTOR 50
#define MAX_LONG_TITULO 80
#define MAX_LONG_ANHO 32767
#define MAX_LONG_VOTANTES 32767
#define MAX_LONG_VOTOS 2147483647
#define MAX_LONG_CRITICOS 32767
#define MAX_LONG_LECTOR 32767
#define MAX_LONG_OPINION 80
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
//STRUCTS-------------------------------------------
struct lectores{
    int codigo;
    char nombre[256];};
struct informacion{
    int lector;
    char opinion[80];};
struct referencia{
    int signatura;
    char tipo;
    char autor[51];
    char titulo[82];
    int anio;
    int votantes;
    int votos;
    int criticos;
	struct informacion info[100];};
struct lectores lect[100];
struct referencia refe[100];
void programa(int eleccion);
//BASICAS--------------------------------------------
void lector(int *ult_lect);
void referencia(int *id);
void opinion (int ult_sign,int ult_lect);
void informa(int ult_sign);
void voto(int ult_sign);
void nota(int ult_sign);
//AVANZADAS------------------------------------------
void listar(int ult_sign);
void buscar(int ult_sign);
	int compara(char *cadena1,char *cadena2);
	void imprime_bus(int x,int *correcto);
void cambiar(int tam_lec);
	void dame_cadenas(char *buscar, char *nuevo);
	char dame_confirmacion(int x);
	void cambiarr(int x, char *nuevo,char *buscar);
//REFERENCIA-----------------------------------------
void dame_cadena(int limite ,char *pantalla,char *cadena2);
int dame_numero(int limite1, int limite2, char *pantalla);
char dame_tipo();
//LEER TXTs----------------------------------------
int leer_lector();
int leer_referencia();
void signaturas(char *cadena, int *sign);
void opiniones(char *cadena, int *opinion, int *sign);
void leer_info(char *cadena, char *texto,int pos);
//ACTUALIZAR TXTs------------------------------------
void actualizar_lector (int ult_lect);
void actualizar_refe (int ult_sing);
//IMPRIMIR-------------------------------------------
void imprimir(int linea);
//COMPROBAR TXTs------------------------------------
int comprobacion();
int comprobar_lectores();
int comprobar_referencias();
int comprobar_puntos(char *cadena,int n_pts);
int comprobar_numero(char *cadena,int tam, int sitio, int *numero,char ORDEN);
int comprobar_cadena(char *cadena,int tam,int sitio);
int comprobar_tipo(char *cadena,int tam);
