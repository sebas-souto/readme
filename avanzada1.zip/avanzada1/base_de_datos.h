#define MAX_LONG_CODIGO 32767
#define MAX_LONG_NOMBRE 50
#define MAX_LONG_SINGNATURA 2147483647
#define MAX_LONG_AUTOR 50
#define MAX_LONG_TITULO 80
#define MAX_LONG_ANHO 32767
#define MAX_LONG_VOTANTES 32767
#define MAX_LONG_VOTOS 2147483647
#define MAX_LONG_CRITICOS 32767
#define MAX_LONG_LECTOR 32767
#define MAX_LONG_OPINION 80
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
//STRUCTS-------------------------------------------
struct lectores{
    int codigo;
    char nombre[256];
};
struct informacion{
    int lector;
    char opinion[80];
};
struct referencia{
    int signatura;
    char tipo;
    char autor[51];
    char titulo[82];
    int anio;
    int votantes;
    int votos;
    int criticos;
	struct informacion info[100];
};
struct lectores lector[100];
struct referencia refe[100];
void programa(int eleccion);
//BASICAS--------------------------------------------
void incorporar_lector(int *ult_lect);
void agregar_referencia(int *id);
void obtener_informe(int ult_sign);
void expresar_opinion(int ult_sign,int ult_lect);
void emitir_voto(int ult_sign);
void calcular_nota(int ult_sign);
//AVANZADAS------------------------------------------
void listar_referencia(int ult_sign);
//LECTOR---------------------------------------------
int comprobar_lector(char nombre[MAX_LONG_NOMBRE], int *ultimo);
void asignar_id(char nombre[MAX_LONG_NOMBRE],int *ultimo);
//REFERENCIA-----------------------------------------
void dame_cadena(int limite ,char *pantalla,char *cadena2);
int dame_numero(int limite1, int limite2, char *pantalla);
char dame_tipo();
//ACTUALIZAR TXTs------------------------------------
void actualizar_lector (int ult_lect);
void actualizar_refe (int ult_sing);
//LEER LECTOR----------------------------------------
int leer_lector();
int leer_referencia();
void datos(char *cadena, int *id);
void leer_info(char *cadena, char *texto,int pos);
void opinions(char *cadena, int *id2,int *id);
//IMPRIMIR-------------------------------------------
void imprimir(int linea);
