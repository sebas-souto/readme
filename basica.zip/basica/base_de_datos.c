//BASE DE DATOS
#include "base_de_datos.h"
void programa(int eleccion){
    int tam_lec, tam_ref;
    tam_lec=leer_lector();
	tam_ref=leer_referencia();
	switch(eleccion){
		case 1:
			incorporar_lector(&tam_lec);
			break;
		case 2:
			agregar_referencia(&tam_ref);
			break;
		case 3:
			expresar_opinion(tam_ref,tam_lec);
			break;
		case 4:
			obtener_informe(tam_ref);
			break;
		case 5:
			emitir_voto(tam_ref);
			break;
		case 6:
			calcular_nota(tam_ref);
			break;}
  	int k,z;
//	for(k=0;k<tam_ref;k++)printf("%i:%c:%s:%s:%i:%i:%i:%i\n",refe[k].signatura,refe[k].tipo,refe[k].autor,refe[k].titulo,refe[k].anio,refe[k].votantes,refe[k].votos,refe[k].criticos);
/*	for(k=0;k<tam_ref;k++){
		if(refe[k].criticos!=0){
			for(z=1;z<=refe[k].criticos;z++)printf("%i:%s\n",refe[k].info[k].lector,refe[k].info[k].opinion);}
			}*/
//	for(k=0;k<tam_lec;k++)printf("%i:%s\n",lector[k].codigo,lector[k].nombre);
    actualizar_lector(tam_lec);
	actualizar_refe(tam_ref);
    return;}

/*****************************************************************************************************************************************************************************
******************************************************************************BASICAS*****************************************************************************************
*****************************************************************************************************************************************************************************/
void incorporar_lector (int *ult_lect){//LISTA
    char nombre[256];
    dame_cadena(MAX_LONG_NOMBRE,"\nEscribe el nombre del lector: ",nombre);		//PEDIMOS UN NOMBRE VALIDO
    if(comprobar_lector(nombre,ult_lect)==0) imprimir(4);		//SI YA EXISTE SALIMOS
    else {
        asignar_id(nombre,ult_lect);
        printf("\nLector %s: asignado %i\n\n",lector[*ult_lect-1].nombre,lector[*ult_lect-1].codigo);}
	return;}

void agregar_referencia(int *ult_sign){		//100%LISTA
	char texto[256];    
    refe[*ult_sign].signatura=*ult_sign+1;
    dame_cadena(MAX_LONG_AUTOR,"\nEscribe el autor de la referencia: ",texto);
	strcpy(refe[*ult_sign].autor,texto);
	dame_cadena(MAX_LONG_TITULO,"\nEscribe el titulo: ",texto);
    strcpy(refe[*ult_sign].titulo,texto);
    refe[*ult_sign].anio=dame_numero(1451,2016,"\nEscribe el anho: ");
/*    dame_cadena(1,"\nEscribe el tipo: ",texto);
    refe[*ult_sign].tipo=texto[0];*/
	dame_tipo(*ult_sign);
    refe[*ult_sign].criticos=0;
    refe[*ult_sign].votantes=0;
    refe[*ult_sign].votos=0;
    printf("\nReferencia %c:%s:%s:%i: asignada %i\n",refe[*ult_sign].tipo,refe[*ult_sign].autor,refe[*ult_sign].titulo,refe[*ult_sign].anio,refe[*ult_sign].signatura);
    *ult_sign+=1;
    return;}

void expresar_opinion(int ult_sign,int ult_lect){//LISTA
    int codigo, id;
	char opinion[MAX_LONG_OPINION];
    if(ult_sign==0||ult_lect==0) printf("\nOperacion imposible en este momento\n");	//SI NO HAY REFERENCIAS NI LECTORES SE ACABA LA FUNCION
    else {
        id = dame_numero(1,ult_sign,"\nEscribe la signatura: ");
        codigo = dame_numero(1,ult_lect,"\nEscribe el codigo: ");
        dame_cadena(MAX_LONG_OPINION, "\nEscribe el comentario: ", opinion);

        refe[id - 1].criticos++;
        refe[id - 1].info[refe[id - 1].criticos].lector = codigo;
        strcpy(refe[id - 1].info[refe[id - 1].criticos].opinion, opinion);

        printf("\nOpinion registrada\n");}
    return;}

void obtener_informe(int ult_sign){//LISTA
    int x, p=0, id;
    if(ult_sign==0) printf("\nOperacion imposible en este momento\n");
    else {
        id = dame_numero(1,ult_sign,"\nEscribe la signatura: ");
        printf("\nNumero de comentarios:%i", refe[id - 1].criticos);
        for (x = refe[id - 1].criticos; x > 0; x--) p++;
        if (refe[id - 1].criticos != 0) {
            for (x = refe[x].criticos; x > 0; x--) {
                printf("\n%s:%s", lector[refe[id - 1].info[x].lector - 1].nombre, refe[id - 1].info[x].opinion);}
        }
        printf("\n");}
    return;}

void emitir_voto(int ult_sign){//LISTA
    int id, voto;
    if (ult_sign == 0) printf("\nOperacion imposible en este momento\n");
    else {
        id = dame_numero(1,ult_sign,"\nEscribe la signatura: ");
        voto = dame_numero(0,10,"\nEscribe el voto: ");
        refe[id - 1].votos += voto;    //SUMAMOS EL VALOR DE VOTO AL VALOR DE VOTOS DE ESA ID
        refe[id - 1].votantes++;        //E INCREMENTAMOS VOTANTES EN 1
        printf("\nVoto registrado\n");}
    return;}

void calcular_nota(int ult_sign){//LISTA
    if (ult_sign == 0) printf("\nOperacion imposible en este momento\n");	//SI NO HAY REFERENCIAS ACABA LA FUNCION
    else {
        int id = dame_numero(1,ult_sign,"\nEscribe la signatura: ");
        printf("\nNumero de votos:%i", refe[id - 1].votantes);
        if (refe[id - 1].votos == 0) printf("\nNota media:0.00\n");
        else printf("\nNota media:%.2f\n",(float) refe[id - 1].votos / refe[id - 1].votantes);}
    return;}
/*****************************************************************************************************************************************************************************
******************************************************************************AGREGAR LECTOR**********************************************************************************
*****************************************************************************************************************************************************************************/
int comprobar_lector(char nombre[MAX_LONG_NOMBRE], int *ultimo){		//100%LISTA
    int i;
    for(i=0;i<*ultimo;i++){
        if ((strcmp(nombre,lector[i].nombre))==0) return 0;}
    return 1;}

void asignar_id(char nombre[MAX_LONG_NOMBRE],int *ultimo){		//100%LISTA
	*ultimo+=1;
    strcpy(lector[*ultimo-1].nombre,nombre);
    lector[*ultimo-1].codigo=*ultimo;}
/*****************************************************************************************************************************************************************************
******************************************************************************DAME DATOS**************************************************************************************
*****************************************************************************************************************************************************************************/
void dame_cadena (int limite,char *pantalla, char *cadena2){	//PENDIENTE REVISAR
    int i, correcto;
    char cadena[256];
    do{
        printf("%s",pantalla);
        fgets(cadena,sizeof(cadena),stdin);
        correcto=1; i=0;
		if(limite+1<strlen (cadena)) while (fgetc(stdin) != '\n');
        if (cadena[0]=='\n'){    				          //CADENA VACIA
            correcto=0;
            imprimir(2);}
        else if (cadena[strlen(cadena)-1] != '\n'){       //LONGITUD CADENA EXCESIVA
            correcto=0;
            imprimir(3);
            while (fgetc(stdin) != '\n');}
        else {                                            //CARACTER INVALIDO
            while (i<strlen(cadena)){
                if (cadena[i]==':'){ correcto=0; imprimir(1);}
                i++;}
		}
    }while (correcto==0); //PIDE EL NOMBRE HASTA UNA INTRODUCCION CORRECTA
    cadena[strlen(cadena)-1]='\0';
    strcpy(cadena2,cadena);}

int dame_numero(int limite1, int limite2, char *pantalla){			//100%LISTA
	int k, numero, correcto;
	char cadena[256];
	do{
    	correcto=1;
        printf("%s",pantalla);
        fgets(cadena,sizeof(cadena),stdin);
        for(k=0;k<strlen(cadena)-1;k++){
        	if(isdigit(cadena[k])==0) correcto=0;}
        numero=atoi(cadena);
        if (numero<limite1 || numero>limite2) correcto=0;
        if (correcto==0) imprimir(5);
    } while (correcto==0);

	return numero;}

void dame_tipo(int sign){		//100%LISTA
    int correcto=0;
    char tipo[256];
	do{
		dame_cadena(1,"\nEscribe el tipo: ",tipo);
		tipo[0]=toupper(tipo[0]);
		if(tipo[0]=='L'||tipo[0]=='A') correcto=1;
        else imprimir(1);		
	}while(correcto==0);
	
    refe[sign].tipo=tipo[0];
    return;}
/*****************************************************************************************************************************************************************************
******************************************************************************ACTUALIZAR TXTS*********************************************************************************
*****************************************************************************************************************************************************************************/
void actualizar_lector (int ult_lect){//LISTA
    int i;
    FILE *archivo;
    archivo = fopen("lectores.txt", "w");
    for (i=0; i<ult_lect; i++) {
        fprintf(archivo,":%i:%s:\n", lector[i].codigo,lector[i].nombre);}
    fclose(archivo);
    return;}

void actualizar_refe (int ult_sing) {//LISTA
    int x, z;
    FILE *archivo;
    archivo = fopen("referencias.txt", "w");
    for (x=0; x<ult_sing; x++) {
    	
        fprintf(archivo,":%i:%c:%s:%s:%i:%i:%i:%i:\n", refe[x].signatura, refe[x].tipo, refe[x].autor, refe[x].titulo, refe[x].anio, refe[x].votantes, refe[x].votos, refe[x].criticos);
		if(refe[x].criticos!=0) {
           for (z = 1; z <= refe[x].criticos; z++)
               fprintf(archivo, "#%i:%s:\n", refe[x].info[z].lector, refe[x].info[z].opinion);}
    }
    fclose(archivo);
	return;}
/*****************************************************************************************************************************************************************************
*******************************************************************************LEER TXTS**************************************************************************************
*****************************************************************************************************************************************************************************/
int leer_lector(){
    char cadena[256];
    char informacion[256];
    int lect=0;
    FILE *archivo;
    archivo = fopen("lectores.txt", "r");

    while(fgets(cadena,sizeof(cadena),archivo)!=NULL){
    	leer_info(cadena,informacion,1);
    	lector[lect].codigo=atoi(informacion);
    	leer_info(cadena,informacion,2);
		strcpy(lector[lect].nombre,informacion);
        lect++;}
    fclose(archivo);
    return lect;}

int leer_referencia(){
    char cadena[256];
    int sign=0,id2=0;
    FILE *archivo;
    archivo = fopen("referencias.txt", "r");

    while(fgets(cadena,sizeof(cadena),archivo)!=NULL){
        if(cadena[0]==':'){
            datos(cadena, &sign);
            sign++;
            id2=refe[sign-1].criticos;}

        else if(cadena[0]=='#'){
			opinions(cadena,&id2,&sign);
            id2--;}
    }
    fclose(archivo);
    return sign;}

void datos(char *cadena, int *sign){
	char informacion[256];
    leer_info(cadena,informacion,1);
    refe[*sign].signatura=atoi(informacion);
    leer_info(cadena,informacion,2);
    refe[*sign].tipo=informacion[0];
    leer_info(cadena,informacion,3);
    strcpy(refe[*sign].autor,informacion);
    leer_info(cadena,informacion,4);
    strcpy(refe[*sign].titulo,informacion);
    leer_info(cadena,informacion,5);
    refe[*sign].anio=atoi(informacion);
    leer_info(cadena,informacion,6);
    refe[*sign].votantes=atoi(informacion);
    leer_info(cadena,informacion,7);
    refe[*sign].votos=atoi(informacion);
    leer_info(cadena,informacion,8);
    refe[*sign].criticos=atoi(informacion);}

void opinions(char *cadena, int *id2, int *id){
    char informacion[256];
	leer_info(cadena,informacion,1);
	refe[*id-1].info[*id2].lector=atoi(informacion);
    leer_info(cadena,informacion,2);
    strcpy(refe[*id-1].info[*id2].opinion, informacion);}

void leer_info(char *cadena, char *texto,int pos){
	int k, posicion, puntos=0;
	
	for(k=0;puntos<pos;k++){		//BUSCA EL INICIO DEL TEXTO EN LA CADENA
		if(cadena[k]==':'||cadena[k]=='#') {posicion=k+1; puntos++;}
	}
	for(k=posicion;cadena[k]!=':';k++){
		texto[k-posicion]=cadena[k];}	//PASA EL CONTENIDO DESEADO A TEXTO
	texto[k-posicion]='\0';	
	return;}
/*****************************************************************************************************************************************************************************
********************************************************************************IMPRIMIR**************************************************************************************
*****************************************************************************************************************************************************************************/
void imprimir(int linea){
    char *errores[]={
            /*0*/   "\nError de formato en un fichero: ?Linea mal formada en el fichero (NOMBRE_FICHERO)\n",
            /*1*/   "\nCaracter invalido\n",
            /*2*/   "\nCadena vacia\n",
            /*3*/   "\nLongitud de la cadena excesiva\n",
            /*4*/   "\nLector repetido\n",
            /*5*/ 	"\nValor seleccionado incorrecto\n",
            /*6*/ 	"\nOperacion imposible en este momento\n",
    };
    printf("%s",errores[linea]);
    return;}
