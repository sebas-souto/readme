#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define LONGITUD 50
struct informacion{
    int lector;
    char opinion[80];
};
struct referencia{
    int signatura;
    char tipo;
    char autor[51];
    char titulo[81];
    int anio;
    int votantes;
    int votos;
    int criticos;
    struct informacion info[100];

};
struct referencia refe[100];
int leer_referencia();
void emitir_voto(int tamanio);
void calcular_nota(int tamanio);

void datos(char *cadena, int *id);
int puntos(char *cadena,int *pts);
void signa(char *cadena, int *pts,int *id);
void tipo(char *cadena, int *pts, int *id);
void autor(char *cadena, int *pts, int *id);
void titulo(char *cadena, int *pts, int *id);
void anho(char *cadena, int *pts,int *id);
void votantes(char *cadena, int *pts,int *id);
void votos(char *cadena, int *pts,int *id);
void criticos(char *cadena, int *pts,int *id);
void opinions(char *cadena, int *id2,int *id);
void lect(char *cadena, int *pts, int *id2, int *id);
void opinion(char *cadena, int *pts, int *id2, int *id);




void actualizar_refe (int *limite);



void agregar_referencia(int *id);
void dame_autor(int *id);
void dame_titulo(int *id);
void dame_anio(int *id);
void dame_tipo(int *id);
void imprimir(int linea);
void confimar (int limite ,char *pantalla,char *cadena2);




struct lectores{
    int codigo;
    char nombre[256];

};

struct lectores lector[100];
int incorporar_lector(int *limite);

void obtener_codigo(char *cadena, int *pts,int *id);
int leer_lector();
void obtener_nombre(char *cadena, int *pts,int *id);
int obtener_puntos(char *cadena,int *pts);
int comprobar_lector(char nombre[50], int *tamanio);
void asignar_id(char nombre[LONGITUD],int *limite);
void actualizar_txt (int *limite);





void obtener_informe(int *tamanio);
void expresa_opinion(int *tamanio,int *tam_lector);

