//TITULO MENU & CONFIRMACION SALIDA
#include "pantalla.h"
	
void lados(char simbolo, int ancho, int lineas){
	if (ANCHO_MAXIMO<ancho) ancho=ANCHO_MAXIMO;
	int k,i;
	for (i=0;i<lineas;i++){
			printf("%c",simbolo);
		for(k=0;k<ancho-2;k++) printf(" ");
		printf("%c\n",simbolo);}
	return;}

void base(char simbolo, int ancho){
	if (ANCHO_MAXIMO<ancho) ancho=ANCHO_MAXIMO;
	int k;
	for(k=0;k<ancho;k++) printf("%c",simbolo);
	printf("\n");		
	return;}
	
int titulo(char simbolo, int ancho, char *texto){
	if (ANCHO_MAXIMO<ancho) ancho=ANCHO_MAXIMO;
	if (ancho<strlen(texto)+2) return 1;   //SI EL ANCHO ES INSUFICIENTE RETORNA 1
	int k, lado, resto;
	lado=ancho-2-strlen(texto);
	resto=strlen(texto)%2;
	
	printf("%c",simbolo);
	for(k=0;k<resto+lado/2;k++) printf(" ");
 	printf("%s",texto);
	for(k=0;k<lado/2;k++) printf(" ");
	printf("%c\n",simbolo);
	return 0;}
	
int confirmar(){
	char cadena[256];
	do{
		printf("\nSeguro que deseas salir del programa? (s/n): ");
		fgets(cadena,sizeof(cadena),stdin);
		if (cadena[1]!='\n') cadena[0]='X';			//SI SE INTRODUCE MAS DE UN CARACTER INVALIDA EL 1o
		cadena[0]=toupper(cadena[0]);
		if (cadena[0]=='S') return 0;	//RETORNA UN 0 CUANDO SE QUIERE SALIR
	} while (cadena[0]!='N');
	return 1;}		//SI SE ESPECIFICA QUE NO SE QUIERE SALIR RETORNA UN 1
