//BASE DE DATOS
#include "base_datos.h"
/*****************************************************************************************************************************************************************************
******************************************************************************BASICAS*****************************************************************************************
*****************************************************************************************************************************************************************************/
void lector (int *ult_lect){//LISTA
    char nombre[256];
    int i;
    dame_cadena(MAX_LONG_NOMBRE,"\nEscribe el nombre del lector: ",nombre);		//PEDIMOS UN NOMBRE VALIDO
    
    for(i=0;i<*ult_lect;i++){		//RECORREMOS TODOS LOS NOMBRES PARA VER SI YA EXISTE
        if ((strcmp(nombre,lect[i].nombre))==0){
		error(4);
		return;}		
	}		
	//SI YA EXISTE SALIMOS Y SI NO EXISTE:
    lect[*ult_lect].codigo=*ult_lect+1;		//LE ASIGNAMOS EL ULTIMO CODIGO +1
	strcpy(lect[*ult_lect].nombre,nombre);		//A�ADIMOS EL NUEVO LECTOR    
    printf("\nLector %s: asignado %i\n",lect[*ult_lect].nombre,lect[*ult_lect].codigo);
    *ult_lect+=1;		//INCREMENTAMOS EL NUMERO DE LECTORES EN 1
	return;}

void referencia (int *ult_sign){//LISTA
	char texto[256];    
    refe[*ult_sign].signatura=*ult_sign+1;		//LE DAMOS A LA REFERENCIA EL NUMERO SIGUIENTE A LA ULTIMA
    dame_cadena(MAX_LONG_AUTOR,"\nEscribe el autor de la referencia: ",texto);
	strcpy(refe[*ult_sign].autor,texto);
	dame_cadena(MAX_LONG_TITULO,"\nEscribe el titulo: ",texto);
    strcpy(refe[*ult_sign].titulo,texto);
    refe[*ult_sign].anio=dame_numero(1450,2017,"\nEscribe el anho: ");
    refe[*ult_sign].tipo=dame_tipo();
    refe[*ult_sign].criticos=0;
    refe[*ult_sign].votantes=0;
    refe[*ult_sign].votos=0;
    printf("\nReferencia %c:%s:%s:%i: asignada %i\n",refe[*ult_sign].tipo,refe[*ult_sign].autor,refe[*ult_sign].titulo,refe[*ult_sign].anio,refe[*ult_sign].signatura);
    *ult_sign+=1;
    return;}

void opinion (int ult_sign,int ult_lect){//LISTA
    int codigo, id;
	char opinion[256];
    if(ult_sign==0||ult_lect==0) error(6);	//SI NO HAY REFERENCIAS NI LECTORES SE ACABA LA FUNCION
    else {
        id = dame_numero(1,ult_sign,"\nEscribe la signatura: ");	//DECIMOS SOBRE QUE SIGNATURA COMENTAMOS
        codigo = dame_numero(1,ult_lect,"\nEscribe el codigo: ");	//DECIMOS QUE LECTOR COMENTA (DEBE ESTAR YA REGISTRADO)
        dame_cadena(MAX_LONG_OPINION, "\nEscribe el comentario: ", opinion);	//ESCRIBIMOS LA OPINION

        refe[id - 1].criticos++;		//AUMENTAMOS EL NUMERO DE CRITICOS DE ESA SIGNATURA EN 1
        refe[id - 1].info[refe[id - 1].criticos].lector = codigo;		//LE ASIGNAMOS EL CODIGO DEL LECTOR AUTOR DE LA OPINION
        strcpy(refe[id - 1].info[refe[id - 1].criticos].opinion, opinion);		//GUARDAMOS LA OPINION PAREJA AL LECTOR

        printf("\nOpinion registrada\n");}
    return;}

void informa (int ult_sign){//LISTA
    int x, id;
    if(ult_sign==0) error(6);		//SI NO HAY REFERENCIAS SE ACABA LA FUNCION
    else {
        id = dame_numero(1,ult_sign,"\nEscribe la signatura: ");		//DECIMOS SOBRE QUE SIGNATURA QUEREMOS VER LAS OPININIONES
        printf("\nNumero de comentarios:%i", refe[id - 1].criticos);	//MOSTRAMOS EL NUMERO DE COMENTARIOS QUE HAY SOBRE ESA SIGNATURA
        if (refe[id - 1].criticos != 0)			//SI HAY ALGUNO LOS MOSTRAMOS
            for (x = 1; x <= refe[id-1].criticos; x++) 
                printf("\n%s:%s", lect[refe[id - 1].info[x].lector - 1].nombre, refe[id - 1].info[x].opinion); 	//MOSTRAMOS EL AUTOR DEL COMENTARIO MAS EL COMENTARIO
        printf("\n");}
    return;}

void voto (int ult_sign){//LISTA
    int id, voto;
    if (ult_sign == 0) error(6);		//SI NO HAY REFERENCIAS SE ACABA LA FUNCION
    else {
        id = dame_numero(1,ult_sign,"\nEscribe la signatura: ");	//DECIMOS SOBRE QUE SIGNATURA QUEREMOS EMITIR UN VOTO
        voto = dame_numero(0,10,"\nEscribe el voto: ");			//ESCRIBIMOS EL VOTO
        refe[id - 1].votos += voto;    //SUMAMOS EL VALOR DE VOTO AL VALOR DE VOTOS DE ESA ID
        refe[id - 1].votantes++;        //E INCREMENTAMOS VOTANTES EN 1
        printf("\nVoto registrado\n");}
    return;}

void nota (int ult_sign){//LISTA
    if (ult_sign == 0) error(6);		//SI NO HAY REFERENCIAS SE ACABA LA FUNCION
    else {
        int id = dame_numero(1,ult_sign,"\nEscribe la signatura: ");		//DECIMOS SOBRE QUE SIGNATURA QUEREMOS VER LA NOTA MEDIA
        printf("\nNumero de votos:%i", refe[id - 1].votantes);		//MOSTRAMOS EL NUMERO DE VOTOS(VOTANTES)
        if (refe[id - 1].votantes == 0) printf("\nNota media:0.00\n");		//SI NO TIENE NINGUN VOTO MOSTRAMOS UN 0
        else printf("\nNota media:%.2f\n",(float) refe[id - 1].votos / refe[id - 1].votantes);}		//SI LO TIENE MOSTRAMOS EL RESULTADO DE VOTOS/VOTANTES (NOTA MEDIA)
    return;}
/*****************************************************************************************************************************************************************************
******************************************************************************AVANZADAS***************************************************************************************
*****************************************************************************************************************************************************************************/
void listar (int ult_sign){//LISTA
	char tipo[256];
    int x;
	do{	//MIENTRAS NO SE SELECCIONE UNICAMENTE EL CARACTER DEL TIPO DE REFERENCIAS A LISTAR LO SEGUIREMOS PIDIENDO
    	printf("\nL)Libros\nA)Articulos\n\nElige el tipo de referencias que quieres listar: ");
        fgets(tipo,sizeof(tipo),stdin);
		tipo[0]=toupper(tipo[0]);
		if(tipo[0]=='L'||tipo[0]=='A') x=1;
		if(tipo[1]!='\n') x=0;
        if(x==0) error(7);		
	}while(x==0);
	
    for(x=0;x<ult_sign;x++)
        if(refe[x].tipo==tipo[0])	//LISTAMOS LAS REFERENCIAS DE ESE TIPO
            printf("\n%i) %s. \"%s\" (%i)",refe[x].signatura,refe[x].autor,refe[x].titulo,refe[x].anio);
	if(x!=0) printf("\n");
	return;}
/*############################################################################################################################################################################
###############################################################################BUSCAR#######################################################################################*/
void buscar (int ult_sign){//LISTA
    char cadena[256];
	int x, correcto=0;
    do {	//PEDIMOS UNA CADENA A BUSCAR QUE NO DEBE SER NULA
    	printf("\nDame la cadena de busqueda: ");
    	fgets(cadena,sizeof(cadena),stdin);
    	for(x=0;x<strlen(cadena)-1;x++)
        	if(cadena[x]!=' '&&cadena[x]!='	') correcto=1;	//SOLO ES VALIDA SI CONTIENE MINIMO UN CARACTER QUE NO SEA ESPACIO NI TABULADOR

        if (cadena[0] == '\n') correcto=0;
        	
        if (correcto==0) error(8);
    }while(correcto==0);
    cadena[strlen(cadena)-1]='\0';
    
    for(x=0;x<ult_sign;x++){	//RECORREMOS LA STRUCT DE SIGNATURAS BUSCANDO
    	if(compara(cadena,refe[x].autor)==0) correcto=imprime_bus(x);	//BUSCAMOS EN AUTOR Y SI COINCIDE IMPRIMIMOS
    	if(compara(cadena,refe[x].titulo)==0) correcto=imprime_bus(x);}	//BUSCAMOS EN TITULO Y SI COINCIDE IMPRIMIMOS
    if(correcto==1) printf("\nNinguna referencia contiene la cadena de busqueda\n");
    return;}
    
int compara(char *buscada,char *cadena){
    char p1[256],datos[256];
    int p,y,inicio=0,fin=strlen(buscada)+1;
    strcpy(datos,cadena);
	
    while(fin<strlen(datos)+2) {
        y=0;
        for (p =inicio; p < fin-1; p++) {
            p1[y] = datos[p];
            y++;}
    	p1[fin-1]='\0';
        if (strcmp(buscada, p1)==0) return 0;	//SI SE ENCUENTRA LO BUSCADO RETORNAMOS 0
        inicio++;
        fin++;}
    return 1;}		//SI NO HAY COINCIDENCIAS RETORNAMOS 1
    
int imprime_bus(int x){//LISTA
    int y;		//SI EXISTE COINCIDENCIA SE IMPRIME Y X ES LA SIGNATURA A IMPRIMIR	
    printf("\n%i) [%c] %s. \" %s\" (%i)\n",refe[x].signatura,refe[x].tipo,refe[x].autor,refe[x].titulo,refe[x].anio);
    if(refe[x].criticos!=0)	//SI EXISTEN OPINIONES LAS IMPRIMIMOS A CONTINUACION DE LA SIGNATURA
        for(y=1;y<=refe[x].criticos;y++)	//IMPRIMIMOS LA OPINION PRECEDIDA DE SU AUTOR
            printf("%s -> %s\n",lect[refe[x].info[y].lector-1].nombre,refe[x].info[y].opinion);
    return 0;} //CUANDO IMPRIMIMOS PASAMOS CORRECTO A 0 PARA INDICAR QUE SE IMPRIMIO ALGO
/*#############################################################################################################################################################################
###############################################################################CAMBIAR#######################################################################################*/
void cambiar (int ult_lect){
	char buscar[256], nuevo[256], sigo;
    int x, correcto=0,cambio=0,inicio;
    dame_cadenas(buscar,nuevo); //PEDIMOS LAS CADENAS
	printf("\n");
    x=0;
    do{
    	while(x<=ult_lect||correcto==0){//Referemos el struct
			x++;
			//printf("*Nombres: %s--\n",lector[x-1].nombre);
			correcto=compara2(buscar,lect[x-1].nombre,&inicio);
			//printf("*Correcto ->%i--\n",correcto);			
		if(correcto==0){
			sigo=dame_confirmacion(x-1);
    			if(sigo=='S') {sustituir(x-1,nuevo,buscar,inicio);correcto=1;cambio++;return;}
			if(sigo=='N')correcto=0;} //CAMBIAMOS EL LECTOR
		}//while
    if(correcto!=1 ||cambio==0) {
	printf("\nNingun lector cambiado\n");//SI NO ENCUENTRA EL LECTOR ACABA AQUI
	return;}
    }while(x<=ult_lect||sigo=='S');   
    return;}
    
void dame_cadenas(char *buscar, char *nuevo){//LISTA
	int x, correcto=0;
	do{		//PEDIMOS LA CADENA A BUSCAR (PARA SUSTITUIR) HASTA QUE SE DE UNA VALIDA
    	printf("\nDame el texto de busqueda: ");
    	fgets(buscar,256,stdin);
    	for(x=0;x<strlen(buscar)-1;x++)
        	if(buscar[x]!='\t'&&buscar[x]!=' ') correcto=1;
        if (buscar[0] == '\n') correcto=0;	//ES DECIR, FORMADA POR ALGUN CARACTER SIN SER TABULADOR NI ESPACIO
        if (correcto==0) error(9);
	}while(correcto==0);
	buscar[strlen(buscar)-1]='\0';

    do{		//PEDIMOS EL TEXTO QUE SUSTITUIRA HASTA QUE SE DE UNO VALIDO
    	correcto=1;
    	printf("\nDame el nuevo texto: ");
    	fgets(nuevo,256,stdin);
    	for(x=0;x<strlen(nuevo);x++)
    	   	if (nuevo[x]==':') correcto=0; 
			if (correcto==0) error(1);
    }while(correcto==0);	//PARA QUE SEA VALIDO SIMPLEMENTE NO DEBE CONTENER EL CARACTER ':'
    nuevo[strlen(nuevo)-1]='\0';	
	return;}
	
char dame_confirmacion(int x){
	char sigo[256];
	int correcto;
	do{
        printf("\nEncontrado: %i) %s\n\nQuieres cambiar a este lector? (s/n): ",lect[x].codigo,lect[x].nombre);
       	fgets(sigo, sizeof(sigo), stdin);
       	sigo[0]=toupper(sigo[0]);
       	if (sigo[0] == 'N' || sigo[0] == 'S') correcto=1; 
      	if (sigo[1] != '\n') correcto=0;   
    } while(correcto==0);
	return sigo[0];}
/*******************************COMPARA-> se usa en buscar y cambiar usuario**************************************************************/
int compara2(char *cadena1,char *cadena2,int *inicio2){//inicio solo se usa en compara, en buscar no hace falta
    char p1[256],cad[256],cad1[256],ini=0;
    int p,y,inicio=0,fin=strlen(cadena1);
    strcpy(cad,cadena1);
    strcpy(cad1,cadena2);
    cad[strlen(cad)]='\0';
    cad1[strlen(cad1)]='\0';
	
    //printf("Cadenas a comparar: %s---%s\n",cad,cad1);
    while(fin<strlen(cad1)+2) {
        y=0;
        for (p =inicio; p < fin; p++) {
            p1[y] = cad1[p];
            y++;}
	ini++;
    	p1[fin]='\0';
	//printf("Cadenas a comparar2: ->%i\n",ini);
	// printf("Cadenas a comparar: %s---%s\n",cad,p1);
        if (strcmp(cad, p1)==0){
		*inicio2=ini;
	 	return 0;
	}
        inicio++;
        fin++;}
    return 1;}
/*****************************************************************************************************************************************/
void sustituir(int x, char *nuevo,char *buscar,int inicio){
    char cambio[256];char cambio2[256];int pos_bus=0,y=0,p=0,tam=0,i=0;	
	char cambio3[256];
    pos_bus=strlen(buscar);
//	printf("--%i\n",inicio);
   if(inicio!=0){
	for(i=0;i<inicio-1;i++){
	//	printf("--%c----%c\n",buscar[0],lector[x].nombre[i]);

		cambio[i]=lect[x].nombre[i];	
	}
    }
    else{
	for(i=0;i<inicio;i++){
	//	printf("--%c----%c\n",buscar[0],lector[x].nombre[i]);
		if(lect[x].nombre[i]==buscar[0])break;
		else {
		cambio[i]=lect[x].nombre[i];
		
		}
	}
     }
	cambio[i]='\0';
	//printf("0--%s\n",cambio);
	//if (i==strlen(lector[x].nombre)) i=0;
	for(y=0;y<strlen(nuevo);y++){//copio lo nuevo
		cambio2[y]=nuevo[tam];
		tam++;
		}
	cambio2[tam]='\0';
	strcat(cambio,cambio2);
	//printf("1--%s\n",cambio);
	for(y=i+pos_bus;y<strlen(lect[x].nombre);y++){//copio lo ultimo
		cambio3[p]=lect[x].nombre[y];
	//	printf("--%c",cambio3[y]);
		p++;
	}
	strcat(cambio,cambio3);
	cambio[i+tam+p]='\0';
	//printf("--%s\n",cambio);
    strcpy(lect[x].nombre,cambio);
	//printf("El inicio de la cadenda--%i----\n",inicio);
    printf("\nLector cambiado a: %i) %s\n",lect[x].codigo,lect[x].nombre);
    return;}
/*****************************************************************************************************************************************************************************
******************************************************************************DAME DATOS**************************************************************************************
*****************************************************************************************************************************************************************************/
void dame_cadena (int limite,char *pantalla, char *cadena){//LISTA
    int i, correcto;
    do{ //PIDE LA INTRODUCCION DE UNA CADENA DE CARACTERES VALIDA
        printf("%s",pantalla);
        fgets(cadena,256,stdin);
        i=0; correcto=1;
        if (cadena[0]=='\n'){    				          //NO PUEDE ESTAR VACIA
            correcto=0;
            error(2);}
        if (limite<strlen(cadena)-1){       //DEBE ESTAR ENTRE 1 Y EL LIMITE INDICADO
            correcto=0;
            error(3);}
        else {                                            //NO DEBE CONTENER EL CARACTER ':'
            while (i<strlen(cadena)){
                if (cadena[i]==':'){
					correcto=0;
					error(1);}
                i++;}
		}
    }while (correcto==0); //PIDE EL NOMBRE HASTA UNA INTRODUCCION CORRECTA
    cadena[strlen(cadena)-1]='\0';	//SUSTITUIMOS EL SALTO DE LINEA POR UN FIN DE LINEA
	return;}

int dame_numero(int limite1, int limite2, char *pantalla){//LISTA
	int k, numero, correcto;
	char cadena[256];
	do{ //PIDE INTRODUCIR UNICAMENTE DIGITOS QUE FORMEN UN NUMERO ENTRE LOS LIMITES ESTABLECIDOS
    	correcto=1;
        printf("%s",pantalla);
        fgets(cadena,sizeof(cadena),stdin);
        for(k=0;k<strlen(cadena)-1;k++){
        	if(isdigit(cadena[k])==0) correcto=0;} //DEBEN SER UNICAMENTE DIGITOS
        numero=atoi(cadena);
        if (numero<limite1 || numero>limite2) correcto=0;	//DEBE ESTAR ENTRE LOS LIMITES PEDIDOS
        if (correcto==0) error(5);
    } while (correcto==0);
	return numero;}	//RETORNA UN NUMERO VALIDO

char dame_tipo(){//LISTA
    int correcto=0;
    char tipo[256];
	do{		//PIDE INTRODUCIR UNA CADENA HASTA QUE SE INTRODUZCA UNICAMENTE 'L' 'A' 'l' 'a'
		dame_cadena(1,"\nEscribe el tipo: ",tipo);
		tipo[0]=toupper(tipo[0]);
		if(tipo[0]=='L'||tipo[0]=='A') correcto=1;
        else error(1);		
	}while(correcto==0);
    return tipo[0];}	//RETORNA EL CARACTER 'L' O 'A'
/*****************************************************************************************************************************************************************************
********************************************************************************IMPRIMIR**************************************************************************************
*****************************************************************************************************************************************************************************/
void error(int linea){
    char *errores[]={
            /*0*/   "\nError de formato en un fichero: ?Linea mal formada en el fichero (NOMBRE_FICHERO)\n",
            /*1*/   "\nCaracter invalido\n",
            /*2*/   "\nCadena vacia\n",
            /*3*/   "\nLongitud de la cadena excesiva\n",
            /*4*/   "\nLector repetido\n",
            /*5*/ 	"\nValor seleccionado incorrecto\n",
            /*6*/ 	"\nOperacion imposible en este momento\n",
            /*7*/	"\nTipo seleccionado no valido\n",
            /*8*/	"\nCadena de busqueda vacia\n",
			/*9*/	"\nTexto vacio\n"};
    printf("%s",errores[linea]);
    return;}
/*****************************************************************************************************************************************************************************
*******************************************************************************LEER TXTS**************************************************************************************
*****************************************************************************************************************************************************************************/
int leer_lector(){//LISTA
    char cadena[256], informacion[256];
    int lector=0;
    FILE *archivo;
    archivo = fopen("lectores.txt", "r");

    while(fgets(cadena,sizeof(cadena),archivo)!=NULL){
    	leer_info(cadena,informacion,1);
    	lect[lector].codigo=atoi(informacion);
    	leer_info(cadena,informacion,2);
		strcpy(lect[lector].nombre,informacion);
        lector++;}
    fclose(archivo);
    return lector;}

int leer_referencia(){//LISTA
    char cadena[256];
    int sign=0, opinion;
    FILE *archivo;
    archivo = fopen("referencias.txt", "r");

    while(fgets(cadena,sizeof(cadena),archivo)!=NULL){
        if(cadena[0]==':'){
            signaturas(cadena, &sign);
            sign++;
			opinion=1;}

        else if(cadena[0]=='#'){
			opiniones(cadena,&opinion,&sign);
            opinion++;}
    }
    fclose(archivo);
    return sign;}

void signaturas(char *cadena, int *sign){//LISTA
	char informacion[256];
    leer_info(cadena,informacion,1);
    refe[*sign].signatura=atoi(informacion);
    leer_info(cadena,informacion,2);
    refe[*sign].tipo=informacion[0];
    leer_info(cadena,informacion,3);
    strcpy(refe[*sign].autor,informacion);
    leer_info(cadena,informacion,4);
    strcpy(refe[*sign].titulo,informacion);
    leer_info(cadena,informacion,5);
    refe[*sign].anio=atoi(informacion);
    leer_info(cadena,informacion,6);
    refe[*sign].votantes=atoi(informacion);
    leer_info(cadena,informacion,7);
    refe[*sign].votos=atoi(informacion);
    leer_info(cadena,informacion,8);
    refe[*sign].criticos=atoi(informacion);
	return;}

void opiniones(char *cadena, int *opinion, int *sign){//LISTA
    char informacion[256];
	leer_info(cadena,informacion,1);
	refe[*sign-1].info[*opinion].lector=atoi(informacion);
    leer_info(cadena,informacion,2);
    strcpy(refe[*sign-1].info[*opinion].opinion, informacion);
	return;}

void leer_info(char *cadena, char *texto,int pos){//LISTA
	int k, posicion, puntos=0;
	
	for(k=0;puntos<pos;k++){		//BUSCA EL INICIO DEL TEXTO EN LA CADENA
		if(cadena[k]==':'||cadena[k]=='#') {posicion=k+1; puntos++;}
	}
	for(k=posicion;cadena[k]!=':';k++){
		texto[k-posicion]=cadena[k];}	//PASA EL CONTENIDO DESEADO A TEXTO
	texto[k-posicion]='\0';	
	return;}
/*****************************************************************************************************************************************************************************
******************************************************************************ACTUALIZAR TXTS*********************************************************************************
*****************************************************************************************************************************************************************************/
void actualizar_lector (int ult_lect){//LISTA
    int i;
    FILE *archivo;
    archivo = fopen("lectores.txt", "w");
    for (i=0; i<ult_lect; i++)
        fprintf(archivo,":%i:%s:\n", lect[i].codigo,lect[i].nombre);
    fclose(archivo);
    return;}

void actualizar_refe (int ult_sing) {//LISTA
    int x, z;
    FILE *archivo;
    archivo = fopen("referencias.txt", "w");
    for (x=0; x<ult_sing; x++) {
        fprintf(archivo,":%i:%c:%s:%s:%i:%i:%i:%i:\n", refe[x].signatura, refe[x].tipo, refe[x].autor, refe[x].titulo, refe[x].anio, refe[x].votantes, refe[x].votos, refe[x].criticos);
		if(refe[x].criticos!=0)
           for (z = 1; z <= refe[x].criticos; z++)
               fprintf(archivo, "#%i:%s:\n", refe[x].info[z].lector, refe[x].info[z].opinion);}
    fclose(archivo);
	return;}
/*****************************************************************************************************************************************************************************
********************************************************************************COMPROBAR TXTS********************************************************************************
*****************************************************************************************************************************************************************************/
int comprobacion(){
	FILE *pf;
	pf = fopen("lectores.txt","r");
	if (pf==NULL) pf=fopen("lectores.txt","w");		//SI NO EXISTE SE CREA EL TXT Y YA NO SE COMPRUEBA
	else if (comprobar_lectores()==0){
		printf("Linea mal formada en el fichero (lectores.txt)\n");
		return 0;}		//SI ESTA MAL FORMADO SE DETIENE Y YA NO SE COMPRUEBA EL SIGUIENTE
		
	FILE *pf2;
	pf2 = fopen("referencias.txt","r");
	if (pf2==NULL) pf2=fopen("referencias.txt","w");
	else if(comprobar_referencias()==0){
		printf("Linea mal formada en el fichero (referencias.txt)\n");
		return 0;}
	fclose(pf);
	fclose(pf2);
	return 1;}		//SI NO ESTAN MAL FORMADOS RETORNAMOS 1
/*****************************************************************************************************************************************/
int comprobar_lectores(){
	char cadena[256];
	int correcto=1, codigo=0;	//CODIGO ALMACENA EL CODIGO ANTERIOR PARA VER SI VAN EN ORDEN ASCENDENTE
	FILE *lectores;
	lectores = fopen("lectores.txt","r");
	while(fgets(cadena,sizeof(cadena),lectores)!=NULL){
		if (cadena[0]==':'){	//EL PRIMER CARACTER DEBE SER :
			if(comprobar_puntos(cadena,3)==0) correcto=0;	//DEBEN EXISTIR 3 ':' POR LINEA Y ACABAR EN ':'
			if(comprobar_numero(cadena,MAX_LONG_CODIGO,1,&codigo,'S')==0) correcto=0; //NUMERO ENTRE 0 Y 16BITS Y EN ORDEN ASCENDENTE
			if(comprobar_cadena(cadena,MAX_LONG_NOMBRE,2)==0) correcto=0;}	//CADENA ENTRE 1 Y 50 CARACTERES SIN ':'
		else correcto=0;}
	fclose(lectores);
	return correcto;}

int comprobar_referencias(){
	char cadena[256];
	int signatura=0, correcto=1;
	FILE *referencias;
	referencias = fopen("referencias.txt","r");
	while(fgets(cadena,sizeof(cadena),referencias)!=NULL){
		if(cadena[0]==':'){
			if(comprobar_numero(cadena,MAX_LONG_SINGNATURA,1,&signatura,'S')==0) correcto=0;
			if(comprobar_tipo(cadena,1)==0) correcto=0;
			if(comprobar_cadena(cadena,MAX_LONG_AUTOR,3)==0) correcto=0;
			if(comprobar_cadena(cadena,MAX_LONG_TITULO,4)==0) correcto=0;
			if(comprobar_numero(cadena,MAX_LONG_ANHO,5,&signatura,'N')==0) correcto=0;
			if(comprobar_numero(cadena,MAX_LONG_VOTANTES,6,&signatura,'N')==0) correcto=0;
			if(comprobar_numero(cadena,MAX_LONG_VOTOS,7,&signatura,'N')==0) correcto=0;
			if(comprobar_numero(cadena,MAX_LONG_CRITICOS,8,&signatura,'N')==0) correcto=0;
	}			
		else if(cadena[0]=='#'){
			if(comprobar_puntos(cadena,2)==0) correcto=0;
			if(comprobar_numero(cadena,MAX_LONG_CODIGO,1,&signatura,'N')==0) correcto=0;
			if(comprobar_cadena(cadena,MAX_LONG_OPINION,1)==0) correcto=0;}
		else correcto=0;}
	fclose(referencias);
	return correcto;}
/*****************************************************************************************************************************************/
int comprobar_puntos(char *cadena,int n_pts){	//falta acabar
	int k, puntos=0;
	if (cadena[strlen(cadena)]=='\n')
		if (cadena[strlen(cadena)-2]!=':') return 0;
	//FALTA VERIFICAR QUE LA ULTIMA LINEA ACABE CON :

	for(k=0;k<strlen(cadena);k++){		//CUENTA LOS PUNTOS EN TODA LA LINEA
		if(cadena[k]==':') puntos++;}
	if (puntos!=n_pts) return 0;	//Y SI NO SE CORRESPONDEN CON LOS DESEADOS RETORNA 0
	return 1;}
/*****************************************************************************************************************************************/
int comprobar_numero(char *cadena,int tam, int sitio, int *numero,char ORDEN){
	int k, posicion, puntos=0, correcto=1;						//CON ORDEN='S' SOLICITAMOS QUE VERIFIQUE SI LOS NUMEROS VAN SECUENCIALMENTE
	char numeroC[256];
	
	for(k=0;puntos<sitio;k++){		//BUSCA EL INICIO DEL TEXTO EN LA CADENA
		if(cadena[k]==':'||cadena[k]=='#') {posicion=k+1; puntos++;}
	}
	for(k=posicion;cadena[k]!=':';k++){		//PASAMOS EL NUMERO DE LA CADENA AL TEXTO
			numeroC[k-posicion]=cadena[k];
			if(isdigit(cadena[k])==0) correcto=0;}	//COMPRUEBA SI ES UN NUMERO
	numeroC[k-posicion]='\0';

	if(k==posicion) return 0;		//SI LA CADENA ESTA VACIA RETORNAMOS 0	
	if(ORDEN=='S'){
		if(atoi(numeroC)!=*numero+1) correcto=0;	//COMPRUEBA QUE LOS NUMEROS VAN SECUENCIALMENTE DESDE EL 1
		*numero=atoi(numeroC);
		if (*numero<1||*numero>tam) correcto=0;}			//COMPRUEBA QUE EL NUMERO ESTA ENTRE 0 Y LA MAXIMA
	else
		if(atoi(numeroC)>tam) correcto=0;	//COMPRUEBA QUE LA LONGITUD DEL NUMERO NO ES EXCESIVA
	return correcto;}
/*****************************************************************************************************************************************/
int comprobar_cadena(char *cadena,int tam,int sitio){
	int k, posicion, puntos=0;
	char texto [256];
			
	for(k=0;puntos<sitio;k++){		//BUSCA EL INICIO DEL TEXTO EN LA CADENA
		if(cadena[k]==':') {posicion=k+1; puntos++;}
	}
	for(k=posicion;cadena[k]!=':';k++){
		texto[k-posicion]=cadena[k];}	//PASA EL CONTENIDO DESEADO A TEXTO
	texto[k-posicion]='\0';
	
	if(k==posicion) return 0;		//SI LA CADENA ESTA VACIA RETORNAMOS 0
	if(strlen(texto)>tam) return 0;		//SI LA LONGITUD ES EXCESIVA RETORNAMOS 0
	return 1;}		//SI TODO OK RETORNAMOS 1
/*****************************************************************************************************************************************/	
int comprobar_tipo(char *cadena,int tam){
	int k, posicion, puntos=0;
	for(k=0;puntos<2;k++){
		if(cadena[k]==':') {posicion=k+1; puntos++;}//BUSCAMOS LA POSICION DONDE SE ENCUENTRAN LOS 2�s ':'
	}	//EN POSICION+1 SE ENCUENTRA TIPO Y EN POSICION +2 DEBERIAN ESTAR LOS 3�s ':'		
	
	if (cadena[posicion+1]!=':') return 0;		//SI EXISTE MAS DE UN CARACTER RETORNAMOS 0
	if (cadena[posicion]!='A'&&cadena[posicion]!='L') return 0;	//SI EL CARACTER NO ES 'L' NI 'A' RETORNAMOS 0
	return 1;} //SI CUMPLE RETORNAMOS 1
