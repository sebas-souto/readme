//PROGRAMA BIBLIOTECA
#include "biblioteca.h"
#include "pantalla.h"
#include "base_de_datos.h"
//#include "base_de_datos.c"
//#include "pantalla.c"

int main(){
	if (comprobacion()==0) return 1;	//COMPRUEBA LOS TXT Y SI ESTAN MAL FORMADOS SE DETIENE EL PROGRAMA
	pantalla('#',80,"BIBLIOTECA");		//CRITERIOS CON LOS QUE SE IMPRIME LA CARATULA
	return 0;}

int comprobacion(){
	FILE *pf;
	pf = fopen("lectores.txt","r");
	if (pf==NULL) pf=fopen("lectores.txt","w");		//SI NO EXISTE SE CREA EL TXT Y YA NO SE COMPRUEBA
	else if (comprobar_lectores()==0){
		printf("Linea mal formada en el fichero (lectores.txt)\n");
		return 0;}		//SI ESTA MAL FORMADO SE DETIENE Y YA NO SE COMPRUEBA EL SIGUIENTE
		
	FILE *pf2;
	pf2 = fopen("referencias.txt","r");
	if (pf2==NULL) pf2=fopen("referencias.txt","w");
	else if(comprobar_referencias()==0){
		printf("Linea mal formada en el fichero (referencias.txt)\n");
		return 0;}
	fclose(pf);
	fclose(pf2);
	return 1;}		//SI NO ESTAN MAL FORMADOS RETORNAMOS 1

int comprobar_lectores(){
	char cadena[256];
	int correcto=1, codigo=0;	//CODIGO ALMACENA EL CODIGO ANTERIOR PARA VER SI VAN EN ORDEN ASCENDENTE
	FILE *lectores;
	lectores = fopen("lectores.txt","r");
	while(fgets(cadena,sizeof(cadena),lectores)!=NULL){
		if (cadena[0]==':'){	//EL PRIMER CARACTER DEBE SER :
			if(comprobar_puntos(cadena,3)==0) correcto=0;	//DEBEN EXISTIR 3 ':' POR LINEA Y ACABAR EN ':'
			if(comprobar_numero(cadena,MAX_LONG_CODIGO,1,&codigo,'S')==0) correcto=0; //NUMERO ENTRE 0 Y 16BITS Y EN ORDEN ASCENDENTE
			if(comprobar_cadena(cadena,MAX_LONG_NOMBRE,2)==0) correcto=0;}	//CADENA ENTRE 1 Y 50 CARACTERES SIN ':'
		else correcto=0;}
	fclose(lectores);
	return correcto;}

int comprobar_referencias(){
	char cadena[256];
	int signatura=0, correcto=1;
	FILE *referencias;
	referencias = fopen("referencias.txt","r");
	while(fgets(cadena,sizeof(cadena),referencias)!=NULL){
		if(cadena[0]==':'){
			if(comprobar_numero(cadena,MAX_LONG_SINGNATURA,1,&signatura,'S')==0) correcto=0;
			if(comprobar_tipo(cadena,1)==0) correcto=0;
			if(comprobar_cadena(cadena,MAX_LONG_AUTOR,3)==0) correcto=0;
			if(comprobar_cadena(cadena,MAX_LONG_TITULO,4)==0) correcto=0;
			if(comprobar_numero(cadena,MAX_LONG_ANHO,5,&signatura,'N')==0) correcto=0;
			if(comprobar_numero(cadena,MAX_LONG_VOTANTES,6,&signatura,'N')==0) correcto=0;
			if(comprobar_numero(cadena,MAX_LONG_VOTOS,7,&signatura,'N')==0) correcto=0;
			if(comprobar_numero(cadena,MAX_LONG_CRITICOS,8,&signatura,'N')==0) correcto=0;
	}			
		else if(cadena[0]=='#'){
			if(comprobar_puntos(cadena,2)==0) correcto=0;
			if(comprobar_numero(cadena,MAX_LONG_CODIGO,1,&signatura,'N')==0) correcto=0;
			if(comprobar_cadena(cadena,MAX_LONG_OPINION,1)==0) correcto=0;}
		else correcto=0;}
	fclose(referencias);
	return correcto;}

int comprobar_puntos(char *cadena,int n_pts){	//falta acabar
	int k, puntos=0;
	if (cadena[strlen(cadena)]=='\n')
		if (cadena[strlen(cadena)-2]!=':') return 0;
	//FALTA VERIFICAR QUE LA ULTIMA LINEA ACABE CON :

	for(k=0;k<strlen(cadena);k++){		//CUENTA LOS PUNTOS EN TODA LA LINEA
		if(cadena[k]==':') puntos++;}
	if (puntos!=n_pts) return 0;	//Y SI NO SE CORRESPONDEN CON LOS DESEADOS RETORNA 0
	return 1;}

int comprobar_numero(char *cadena,int tam, int sitio, int *numero,char ORDEN){
	int k, posicion, puntos=0, correcto=1;						//CON ORDEN='S' SOLICITAMOS QUE VERIFIQUE SI LOS NUMEROS VAN SECUENCIALMENTE
	char numeroC[256];
	
	for(k=0;puntos<sitio;k++){		//BUSCA EL INICIO DEL TEXTO EN LA CADENA
		if(cadena[k]==':'||cadena[k]=='#') {posicion=k+1; puntos++;}
	}
	for(k=posicion;cadena[k]!=':';k++){		//PASAMOS EL NUMERO DE LA CADENA AL TEXTO
			numeroC[k-posicion]=cadena[k];
			if(isdigit(cadena[k])==0) correcto=0;}	//COMPRUEBA SI ES UN NUMERO
	numeroC[k-posicion]='\0';

	if(k==posicion) return 0;		//SI LA CADENA ESTA VACIA RETORNAMOS 0	
	if(ORDEN=='S'){
		if(atoi(numeroC)!=*numero+1) correcto=0;	//COMPRUEBA QUE LOS NUMEROS VAN SECUENCIALMENTE DESDE EL 1
		*numero=atoi(numeroC);
		if (*numero<1||*numero>tam) correcto=0;}			//COMPRUEBA QUE EL NUMERO ESTA ENTRE 0 Y LA MAXIMA
	else
		if(atoi(numeroC)>tam) correcto=0;	//COMPRUEBA QUE LA LONGITUD DEL NUMERO NO ES EXCESIVA
	return correcto;}

int comprobar_cadena(char *cadena,int tam,int sitio){
	int k, posicion, puntos=0;
	char texto [256];
			
	for(k=0;puntos<sitio;k++){		//BUSCA EL INICIO DEL TEXTO EN LA CADENA
		if(cadena[k]==':') {posicion=k+1; puntos++;}
	}
	for(k=posicion;cadena[k]!=':';k++){
		texto[k-posicion]=cadena[k];}	//PASA EL CONTENIDO DESEADO A TEXTO
	texto[k-posicion]='\0';
	
	if(k==posicion) return 0;		//SI LA CADENA ESTA VACIA RETORNAMOS 0
	if(strlen(texto)>tam) return 0;		//SI LA LONGITUD ES EXCESIVA RETORNAMOS 0
	return 1;}		//SI TODO OK RETORNAMOS 1
	
int comprobar_tipo(char *cadena,int tam){
	int k, posicion, puntos=0;
	for(k=0;puntos<2;k++){
		if(cadena[k]==':') {posicion=k+1; puntos++;}//BUSCAMOS LA POSICION DONDE SE ENCUENTRAN LOS 2�s ':'
	}	//EN POSICION+1 SE ENCUENTRA TIPO Y EN POSICION +2 DEBERIAN ESTAR LOS 3�s ':'		
	
	if (cadena[posicion+1]!=':') return 0;		//SI EXISTE MAS DE UN CARACTER RETORNAMOS 0
	if (cadena[posicion]!='A'&&cadena[posicion]!='L') return 0;	//SI EL CARACTER NO ES 'L' NI 'A' RETORNAMOS 0
	return 1;} //SI CUMPLE RETORNAMOS 1
